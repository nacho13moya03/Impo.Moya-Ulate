﻿namespace ProyectoSC_601.Models
{
    public class ProductoModel
    {
    }
}