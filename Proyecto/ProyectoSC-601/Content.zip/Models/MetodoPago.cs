﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoSC_601.Models
{
    public class MetodoPago
    {
    }
}