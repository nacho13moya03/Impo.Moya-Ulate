﻿namespace ProyectoSC_601.Entities
{
    public class InfoIndex
    {
        public string Nombre_Completo { get; set; }
        public string Correo { get; set; }
        public string Asunto { get; set; }
        public string Mensaje { get; set; }
    }
}